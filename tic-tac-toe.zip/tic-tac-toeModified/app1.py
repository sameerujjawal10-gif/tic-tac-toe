from flask import Flask, render_template, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'cs_club_secret_key'

# Point Flask to look inside 'templates1' folder
app.template_folder = 'templates1'
app.static_folder = 'static1'

@app.route('/')
def index():
    if 'board' not in session:
        session['board'] = [""] * 9
        session['current_player'] = "X"
        session['winner'] = None
        session['draw'] = False
    
    return render_template('index1.html', 
                           board=session['board'], 
                           current_player=session['current_player'], 
                           winner=session['winner'], 
                           draw=session['draw'])

@app.route('/move/<int:index>')
def move(index):
    if session.get('winner') or session.get('draw'):
        return redirect(url_for('index'))
    
    board = session['board']
    
    if board[index] == "":
        board[index] = session['current_player']
        
        winning_conditions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], # Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], # Columns
            [0, 4, 8], [2, 4, 6]             # Diagonals
        ]
        
        round_won = False
        for condition in winning_conditions:
            if board[condition[0]] != "" and board[condition[0]] == board[condition[1]] == board[condition[2]]:
                round_won = True
                break
        
        if round_won:
            session['winner'] = session['current_player']
        elif "" not in board:
            session['draw'] = True
        else:
            session['current_player'] = "O" if session['current_player'] == "X" else "X"
        
        session['board'] = board
        
    return redirect(url_for('index'))

@app.route('/reset')
def reset():
    session.pop('board', None)
    session.pop('current_player', None)
    session.pop('winner', None)
    session.pop('draw', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)